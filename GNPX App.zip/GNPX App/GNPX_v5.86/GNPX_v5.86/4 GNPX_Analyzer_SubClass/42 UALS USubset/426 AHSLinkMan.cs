
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using static System.Math;
using static System.Diagnostics.Debug;

using GIDOO_space;
using System.Security.Cryptography.X509Certificates; 
using System.Security.Cryptography;
using System.Xml.Linq;


namespace GNPX_space {

    public class AHSLinkMan: AnalyzerBaseV2{
        private int                 pAHSSizeMax => G6.ALSSizeMax;	// Use ALSSizeMax
        public List<UAnHS>          AHSList;
		static int					_PlsB_ = 0;
		static int					_maxSize_ = 0;

        public bool                 AHS2AHS_Link;   //AHS ->AHS
		public int					stage_nPlus = 0;

		// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
		//   under development (ver 5.9)
		// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*

        public AHSLinkMan( GNPX_AnalyzerMan pAnMan ){
            this.pAnMan = pAnMan;
			this.Initialize();
		}

		public void Initialize(){
            AHSList       = null;
//            LinkCeAlsLst = null;
            AHS2AHS_Link = false;
			stage_nPlus  = 0;
			_PlsB_  = 0;
			_maxSize_ = 0;
        }

		private bool IsHit_stage_nPlus( int nPls ){
			if( stageNoP != (stage_nPlus>>4) ){ stage_nPlus = stageNoP<<4; return false; }
			if( (stage_nPlus & (1<<nPls)) == 0 )  return false;
			stage_nPlus = (stage_nPlus<<4) | (1<<nPls);
			return true;
		}

        public int Prepare_AHSLink_Man( int nPlsB, int maxSize=5, bool setCondInfo=false, bool debugPrintB=false ){
			{
				if( AHSList !=null && AHSList.Count>3 && _PlsB_>=nPlsB && _maxSize_>=maxSize )  return AHSList.Count;
				_PlsB_ = Max( _PlsB_, nPlsB);
				_maxSize_ = Max( _maxSize_, maxSize ); 
			}
		
            AHSList = Create_AHSList( noBMax:8, debugPrint:debugPrintB );


            if(debugPrintB)  AHSList.ForEach( (P,kx) => WriteLine( $"{kx} {P}") );

            return AHSList.Count;  
		}
#if false
		private bool IsPureAHS2( UAnHS UAn ){
			if( UAn.Size == 1 ) return  true;
			foreach( var P in UAn.UCellLst ){
				var Q = UAn.UCellLst.Where(q=>q.rc!=P.rc).Any(q=> (q.FreeB&P.FreeB)==0 );
				if( Q )	return false;
			}

			if( UAn.Size >= 3 ){
				for( int n=2; n<UAn.Size; n++ ){
					Combination cmb = new( UAn.Size, n );
					while(cmb.Successor()){
						int fb = 0;
						for( int k=0; k<n; k++ )  fb |= UAn.UCellLst[ cmb.Index[k] ].FreeB;
						if( fb.BitCount() == n ){
							//WriteLine( UAn );
							return false;
						}
					}
				}
			}
			return true;
		}
#endif

		private List<UAnHS> Create_AHSList( int noBMax, bool debugPrint=false ){
			// maxLevel : max class number of AHS ( 1..maxLevel )
			// size : number of digits

            List<UAnHS>  _tmpAHSList = new() ;

			for(int h=0; h<27; h++ ){       // house 0-8(row) 9-17(column) 18-26(block)
				List<(UInt128,int)> BF9H = new();
				for( int no=0; no<9; no++ ){
					var Q = BOARD_Free81B9[no] & HouseCells81[h];
					if( Q != qZero )  BF9H.Add( (Q,1<<no) );
				}
				if( BF9H.Count() <=0 )  continue;

				int noBMaxT = Min(noBMax, BF9H.Count() );
				var QH = BOARD_Free81 & HouseCells81[h];
				for( int size_noB=1; size_noB<=noBMaxT; size_noB++ ){
					int  sz_nPls = size_noB +1;
					Combination cmb = new(BF9H.Count(),size_noB);
					int nxt = 99;
					while( cmb.Successor(skip:nxt) ){
						int FreeB = 0;
						UInt128 Psigma = qZero;
						for( int k=0; k<size_noB; k++ ){
							nxt = k;
							var (P,noB) = BF9H[cmb.Index[k]];
							Psigma |= P;
							FreeB  |= noB;
							if( Psigma.BitCount() > sz_nPls )  goto nextCmb;
						}
						UAnHS UAHS = new( 0, size_noB, FreeB, Psigma, h );
						if( UAHS.Level>sz_nPls )  goto nextCmb;

						UInt128 freeCell = QH.DifSet(Psigma);
						if( freeCell == qZero )  goto nextCmb;
							if(debugPrint) WriteLine( $"  --> {UAHS}" );
						_tmpAHSList.Add( UAHS );

					nextCmb:
						continue;
					}
				}
			}

			_tmpAHSList = _tmpAHSList.DistinctBy(p =>p.rcB_FreeB_key).ToList();
            _tmpAHSList.Sort( (a,b) => a.CompareTo(b) );
            int ID=0;
            _tmpAHSList.ForEach(P=> P.ID=ID++ );
			if(debugPrint)  _tmpAHSList.ForEach( p=> WriteLine(p));

            return _tmpAHSList;  
        }




#if false
		private List<UAnHS> Create_AHSList_base( int nPls, int minSize, int maxSize ){
            List<UAnHS>  _tmpAHSList = new() ;
            for(int h=0; h<27; h++ ){       // house 0-8(row) 9-17(column) 18-26(block)
                List<UCell> UCells = pBOARD.IEGetCellInHouse(h,0x1FF).ToList();
                if( UCells.Count<1 ) continue;

                int szMax = Min(UCells.Count,8-nPls);
                szMax = Min(szMax,pAHSSizeMax);						// AHS size maximum value
                for( int sz=minSize; sz<=szMax; sz++ ){				// AHS size: Number of cells that make up AHS
                    Combination cmb = new Combination(UCells.Count,sz);
                    while( cmb.Successor() ){						// generate a combination
                        int FreeB = cmb.Index.Aggregate( 0, (p,q) => p| UCells[q].FreeB );
						int FreeBC = FreeB.BitCount();
                        if( FreeBC<=sz || FreeBC>(sz+nPls) ) continue;
               
                        List<UCell> UCellLst = cmb.Index.ToList().ConvertAll(q=> UCells[q]);

                        UAnHS UA = new UAnHS( 0, FreeB, UCellLst, h );
								 
						// Elements contained in only one cell (This is acceptable as AHS)
						// if( IsContainedInOnlyOneUCell(UA) ) continue;	
                    //    if( !UA.IsPureAHS() ) continue;					// Pure AHS : not include LockedSet.
					//	if( !IsPureAHS2(UA) ) continue;
							
						_tmpAHSList.Add(UA);
                    }
                }
            }
                                                                                                                                                                                                                                                                                                         
            _tmpAHSList = _tmpAHSList.DistinctBy(p=>p.bitExp).ToList();
            _tmpAHSList.Sort( (a,b) => a.CompareTo(b) );
            int ID=0;
            _tmpAHSList.ForEach(P=> P.ID=ID++ );
		  //_tmpAHSList.ForEach( p=> WriteLine(p));

            return _tmpAHSList;  
        }
#endif

#if false
        public int  Get_AlsAlsRcc( UAnHS UA, UAnHS UB ){    
			int _ToB(int val, int ix) => (val>0)? 1<<ix:0; 
			int FreeB = UA.FreeB & UB.FreeB;
			int RCC = FreeB.IEGet_BtoNo().Aggregate(0, (p,n) => p|= _ToB( UA.rcbAnd9[n] & UB.rcbAnd9[n] , n) );
/*
            if( FreeB == 0 ) return 0;									// no common digit
            if( (UA.bitExp&UB.bitExp).IsNotZero() )          return 0;  // overlaps　
            if( (UA.connectedB81&UB.bitExp).IsZero() )  return 0;  // no connected

			int RCC = 0;
			foreach( int no in FreeB.IEGet_BtoNo() ){
				if( (UA.BitExp9[no] .DifSet(UB.connected81_9[no]) ) == UInt128.Zero )  RCC |= 1<<no;
				//WriteLine( $"#{no+1}  {UA.BitExp9[no].ToBitString81()}  {UB.connected81_9[no].ToBitString81()}" );
			}
			//if( RCC>0 ){ WriteLine( $"Get_AlsAlsRcc RCC:{RCC.ToBitString()}\n UA:{UA}\n UB:{UB}" ); }
*/
            return RCC;
        }
#endif

#if false
        public IEnumerable<UAnHS> IEGetCellInHouse( int lvl, int noB, UInt128 Area128 ){
            foreach( var P in AHSList.Where(p=>p.Level==lvl) ){
                if( (P.FreeB&noB)==0 )         continue;
                if( (P.bitExp.DifSet(Area128) ).IsNotZero() ) continue;
                yield return P;
            }
        }
#endif

/*
        // Link between Cell#n --> AHS
        //  AHS turns to LockedSet when Cell#n is true.
        public void QSearch_Cell2AHS_Link( ){
            Prepare_AHSLink_Man(1);
            if( LinkCeAlsLst!=null ) return ;
            if( AHSList==null || AHSList.Count<2 )  return;
            LinkCeAlsLst = new List<Link_CellAHS>[81];


            foreach( var PA in AHSList ){
                //debug WriteLine( $"\r{PA}");
                foreach ( var no in PA.FreeB.IEGet_BtoNo() ){
                    int noB=(1<<no);
                    UInt128 H = UInt128.MaxValue;
                    foreach( var P in PA.UCellLst.Where(q=>(q.FreeB&noB)>0)){
                        H = H & ConnectedCells81[P.rc];
                    }
                    if( H.IsZero() ) continue;
                  
                    foreach ( var P in H.IESelect81B_with_noB(pBOARD,noB) ){
                        var Q = new Link_CellAHS(P,PA,no);
                        if( LinkCeAlsLst[P.rc]==null )  LinkCeAlsLst[P.rc]=new List<Link_CellAHS>();
                        LinkCeAlsLst[P.rc].Add(Q);

                        // if P#no is true, PA(AHS) turns to LockedSet.
                        //debug WriteLine( $"no:#{no+1} Q.UC:{Q.UC}" );
                    }
                }
            }
        }
*/

#if false
        public void QSearch_AHS2AHS_Link( ){        // <-- eAHS_Chain
            Prepare_AHSLink_Man( nPlsB:1, setCondInfo:true, debugPrintB:false);

            if( AHS2AHS_Link ) return;
            AHS2AHS_Link=true;

            var cmb = new Combination( AHSList.Count, 2 );
            while( cmb.Successor() ){

                UAnHS UA = AHSList[cmb.Index[0]];
                UAnHS UB = AHSList[cmb.Index[1]];
				//WriteLine( $"\n --UA{UA}\n --UB{UB}" );

                int RCC = Get_AlsAlsRccEx( UA, UB );    // improved! <- Get_AlsAlsRcc( UA, UB );
                if( RCC==0 ) continue;

                if( UA.ConnectedAHS is null ) UA.ConnectedAHS = new();
                UA.ConnectedAHS.Add( (UB,RCC) );	//[ATT] ... The second term is a bit representation.

                if( UB.ConnectedAHS is null ) UB.ConnectedAHS = new();
                UB.ConnectedAHS.Add( (UA,RCC) );	//[ATT] ... The second term is a bit representation.
            }
		}

            // ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- -----
        public int Get_AlsAlsRccEx( UAnHS UA, UAnHS UB ){
            int FreeB_AB = UA.FreeB & UB.FreeB;
            if( FreeB_AB==0 )  return 0;  // no common digit

            int RCC_BitExp = 0;
            foreach( var no in FreeB_AB.IEGet_BtoNo() ){
				if( (UA.rcbAnd9[no] & UB.rcbAnd9[no]) == 0 )  continue;
                RCC_BitExp |= (1<<no); 
			}
				//WriteLine( $"RCC_BitExp:{RCC_BitExp.ToBitString(9)}");
			return RCC_BitExp;
        }
#endif

#if false
        public (UInt128,UInt128) Get_RCC_bitExp( int RCC, UAnHS UA, UAnHS UB, bool debugPrint=false ){
            if( RCC==0 )  return (UInt128.Zero,UInt128.Zero);  // no common digit

			UInt128 RCC_UA_BitExp=UInt128.Zero, RCC_UB_BitExp=UInt128.Zero;
            foreach( var no in RCC.IEGet_BtoNo() ){	
                RCC_UA_BitExp |= UA.BitExp9[no];
				RCC_UB_BitExp |= UB.BitExp9[no];
			}
			if(debugPrint){
				WriteLine( $" UA:{UA.bitExp.ToBitString81()}  UB:{UA.bitExp.ToBitString81()}" );
				for( int no=0; no<9; no++){
					WriteLine( $"  {no+1}:{UA.BitExp9[no].ToBitString81()}   {UA.BitExp9[no].ToBitString81()}" );
				}
			}
			return (RCC_UA_BitExp,RCC_UB_BitExp);
        }
#endif
    } 

}