﻿using GNPX_space;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Math;

using GIDOO_space;

namespace GNPX_space{


	public static class GNPX_Puzzle_Database_Manager{
		static string __bPzlZero = new String('0',81);

        static public   GNPX_Engin      pGNPX_Eng;

		static private List<UPuzzle_Base> _GNPX_Puzzle_List = new();	// Puzzle DB(List)
		static public  List<UPuzzle_Base> GNPX_Puzzle_List{ get => _GNPX_Puzzle_List; }

		static public int				GNPX_Puzzle_Count => (GNPX_Puzzle_List!=null)? GNPX_Puzzle_List.Count: 0;


		static public UPuzzle_Base	current_Puzzle;

		static private int				_current_Puzzle_No;

	//	static bool __setting=false;
		static public int				current_Puzzle_No{  // Consecutive numbers starting with 0
            get=> _current_Puzzle_No;
            set{ 
				if( GNPX_Puzzle_Count <= 0 )  return;
                int nn = Max( value, 0 );;
				nn = Min( nn, GNPX_Puzzle_Count-1 );
				_current_Puzzle_No = nn;
				current_Puzzle = GNPX_Puzzle_List[nn];

				pGNPX_Eng.Set_NewPuzzle( current_Puzzle );  // Set to engine
            }
        }


		static GNPX_Puzzle_Database_Manager(){
		
		}




		// ***** Registration to GNPX_Puzzle_List shall be performed only at this location. *****
		static public void	GNPX_Puzzle_List_Add( UPuzzle_Base bPzl ){
			if( bPzl==null || bPzl.stPuzzle==__bPzlZero )  return;
			_GNPX_Puzzle_List.Add(bPzl);
			current_Puzzle_No = int.MaxValue;
		}

		static public void Set_GNPX_Puzzle_List( List<UPuzzle_Base> Set_GNPX_Puzzle_ListPz_List ){
			_GNPX_Puzzle_List = Set_GNPX_Puzzle_ListPz_List;
			current_Puzzle_No = 0;
		}

		// -----------------------------------------------------------------------

		static public void Set_GNPX_Puzzle_ListGNPX_Remove(){
			GNPX_Puzzle_List.RemoveAt(_current_Puzzle_No);
			current_Puzzle_No = _current_Puzzle_No;
		}


		static public UPuzzle_Base CreateNewPuzzle( UPuzzle ePzl=null ){
			int[] board = (ePzl==null)? Enumerable.Repeat(0,81).ToArray(): ePzl.BOARD.ConvertAll(p=>Max(p.No,0)).ToArray();
			UPuzzle_Base bPzl = new UPuzzle_Base(board);
			GNPX_Puzzle_List_Add(bPzl);
			return  bPzl;
		}


		static public long Get_hashValue_int81( this int[] SolX ){
			long hv = 0;
			for( int rc=0; rc<81; rc++ ){
				if( SolX[rc]>0 )  hv ^= GIDOO_Hash.hashBase[ ((rc)<<6)  | SolX[rc] ];
			}
			return hv;
		}

	}
}