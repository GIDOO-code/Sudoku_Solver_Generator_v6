using System;
using System.Collections.Generic;
using System.Linq;
using static System.Diagnostics.Debug;
using System.Windows.Media;
using static System.Math;
using System.IO;

using GIDOO_space;
using System.Windows.Documents;
using System.Xml.Linq;
using static GNPX_space.Senior_Exocet_TechGen;
using System.Diagnostics;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Windows.Media.Animation;


namespace GNPX_space{
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
	//   under development (GNPXv6)
	//   @@@@@ There are still discrepancies between the Sudoku-6 HP and GNPX-6 codes. @@@@@
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*

	using G6_SF = G6_staticFunctions;
	using TapleUCL = (UCoverLine,UCoverLine,UCoverLine);

    public partial class Senior_Exocet_TechGen: AnalyzerBaseV2{

		private UInt128 ObjectSq(UInt128 obj, int sq ) => obj | ((UInt128)sq)<<100;

		public bool Junior_Exocet_JE2( ) => Exocet_General( ExoControl:"name:JE2" );
		public bool Junior_Exocet_JE1( ) => Exocet_General( ExoControl:"name:JE1" );

				// Type:base : Starting point for Senior Exocet development. This version is to ensure that "Junior Exocet is included."
				//	public bool SExocet_Basic()		 => Exocet_General( ExoControl:"name:SE type:Basic"  );

		public bool SExocet()			 => Exocet_General( ExoControl:"name:SE type:Simple"  );
		public bool SExocet_Single()	 => Exocet_General( ExoControl:"name:SE type:Single"  );
		public bool SExocet_SingleBase() => Exocet_General( ExoControl:"name:SE type:SingleBase"  );




		// [TBD]  Mirror behavior in Senior Exocet

        public bool Exocet_General( string ExoControl ){
			USExocet.qBOARD = pBOARD;
			//bool debugPrint = true;

			// ::: Prepare :::
			if( stageNoP != stageNoPMemo ){
				stageNoPMemo = stageNoP;
				base.AnalyzerBaseV2_PrepareStage();
				Prepare_SExocet_TechGen( printB:false );	//debugPrint );
			}
			ElementElimination_Manager_UT("Initialize");	


			// ::: ��Phase1 :::  ... An instance for determining the shape of the Base.
			foreach( var SExo in IE_SE_ph1_Set_BasicForm1_Set_BasicForm( ExoControl:ExoControl, debugPrint:false) ){			
				//if( SExo.dir!=1 || SExo.rcStem!=69 )  continue;			// ===== SE_Nxt Debug =====
				
				// ::: ��Phase2 ::: 
				foreach( var _ in IE_SE_ph2_Get_TargetObject_SLine( SExo, debugPrint:false) ){
					UCoverLine ExG0=SExo.ExG0, ExG1=SExo.ExG1, ExG2=SExo.ExG2;		// SExo.Companions=SExo.Companions;
					// if( ExG1.Object!=(qOne<<12) || ExG2.Object!=(qOne<<24) )  goto LClear; // ===== SE_Nxt Debug =====
					//if( ExG1.Object != (qOne<<43 | qOne<<44) )  goto LClear; // ===== SE_Nxt Debug =====

					int FreeB_Object = ExG1.FreeB_Object81 | ExG2.FreeB_Object81;
					//if( (SExo.FreeB.DifSet(FreeB_Object)) > 0 )  goto LClear;
					int FreeB_Companions = SExo.Companions.Get_FreeB();

					if( ( SExo.FreeB & FreeB_Companions ) > 0 )  goto LClear;

								if(debugPrint){
									UInt128 ConStem = HC81[ (SExo.dir,SExo.rcStem).DRCHf() ] | HC81[SExo.rcStem.B()+18];
									UInt128 SLineBand  = BOARD_FreeCell81 .DifSet(ConStem);		//

									UInt128 Base_StemAnd = SExo.Base81 | SExo.Band81.Aggregate_ConnectedAnd();
									G6_SF.__MatrixPrint( Flag:Base_StemAnd, ExG0.SLine_x, ExG1.SLine_x, ExG2.SLine_x, "ExG0.SLine_x ExG1.SLine_x ExG2.SLine_x" );
									WriteLine( $"IE_SE_ph3_Get_TargetObject_SLine  ****  ExG1.Object: {ExG1.Object.TBScmpRC()}    ExG2.Object: {ExG2.Object.TBScmpRC()}" );
								}




					{ // *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*		
						// *** Conditions need to be clarified ***

						//debugPrint = true;
						bool IsValid_CL = SE_ph4_IsCoveredExt( SExo, debugPrint:debugPrint );
						if( IsValid_CL is false )  continue;



						// SE_ph4_IsCovered( SExo, debugPrint:debugPrint );

						int[] CL_bySize_noB = SExo.CL_bySize_noB;
						int[] CL_bySize_Count = CL_bySize_noB.ToList().ConvertAll(p => p.BitCount() ).ToArray();

						// :::::: Junior Exocet ::::::
						if( SExo.ExocetName.Contains("JE2") ){			// ... JE2, JE2+, JE2++
							if( CL_bySize_Count[2]<2 || CL_bySize_noB[3]>0 )  goto LClear;
						}
						else if( SExo.ExocetName.Contains("JE1") ){		// ... JE1
							if( CL_bySize_Count[3]!=1 || SExo.FreeB .DifSet(CL_bySize_noB[2] | CL_bySize_noB[3]) > 0 )  goto LClear;
						}



						// :::::: Senior Exocet ::::::
				  		else if( SExo.ExocetNamePlus=="SE_Simple" ){	// ... SE_Simple, SE_SingleBase
							if(  CL_bySize_Count[2]<2 || CL_bySize_noB[3]>0 )  goto LClear;
						}
						else if( SExo.ExocetNamePlus=="SE_Single" ){	// ... SE_Single
							if( CL_bySize_Count[3]!=1 || SExo.FreeB .DifSet(CL_bySize_noB[2] | CL_bySize_noB[3]) > 0 )  goto LClear;
						}
						
						else if( SExo.ExocetNamePlus=="SE_SingleBase" ){	// ... SE_SingleBase
							if(	CL_bySize_Count[2]!=2 || CL_bySize_Count[1]>0 || CL_bySize_Count[3]>0 )  goto LClear;
						}

						else{
							WriteLine( $"\n\n ExocetNamePlus : {SExo.ExocetNamePlus} ... \n\n" );
							throw new Exception( $"Operation Error. SExo.ExocetNamePlus : {SExo.ExocetNamePlus}");
						}

						//WriteLine( $" --- {SExo.ExocetNamePlus}" );
					}




					{ // *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
						//  <<< phase5 >>>  ... Check Roule
						bool solFound = SE_ph5_Exclude_Test( SExo );

						// Preventive defense. Not intelligent. This is not desirable.
						if( !solFound || pBOARD.Any(uc=> uc.No==0 && uc.FreeB0==0) ) goto LClear; 
						// --------------------------------------------------------------------------

						//  <<< phase6 >>>  ... Reporting the results
						SE_ph6_Result( SExo, debugPrint:false );	//debugPrint );
						if( !pAnMan.IsContinueAnalysis() )  return true; // @is Valid
					}


					// =================================================================================
					// <<< Final Processing >>>
				LClear:	
					foreach( var UC in pBOARD.Where(p=>p.No==0) ) UC.CancelB=0;
					pBOARD.ForEach( UC => UC.ECrLst=null );
					ElementElimination_Manager_UT("Initialize");

				}
			}
			return false;			
		}



		private void SE_ph6_Result( USExocet SExo, bool debugPrint ){
			string  ExocetName=SExo.ExocetName, ExocetNamePlus=SExo.ExocetNamePlus;

			UCoverLine ExG1=SExo.ExG1, ExG2=SExo.ExG2;
			var		 (rcBase1,rcBase2) = SExo.Base81.Get_rc1_rc2();
			
			int FreeB0 = SExo.FreeB0;
			UInt128	 SLine1=ExG1.SLine_x, SLine2=ExG2.SLine_x;

			// <<<<< Result ...  coloring, create message  >>>>>
			try{
				SolCode = 2;

			  // ::: Base
				SExo.Base81.IE_SetNoBBgColorNSel( pBOARD, FreeB0, AttCr, SolBkCr );	

			  // ::: Object, Companion, Mirror
				Color cr = SolBkCr2G;
				int FB0 = FreeB0;
				if( (ExocetName.Contains("JE1") || SExo.ExocetNamePlus.Contains("_Single")) && SExo.ExG1.wildcardB && ExG1.Object!=_na_){
					SExo.ExG1.Object.IE_SetNoBBgColor_All( pBOARD, AttCr, SolBkCr2G ); 
				}

				if( ExocetNamePlus.Contains("SE_SingleBase") ){
					if( SExo.ExG1.phantomObjectB ) SExo.ExG1.Object.IE_SetNoBBgColor_All( pBOARD, AttCr, SolBkCr2G ); 
					if( SExo.ExG2.phantomObjectB ) SExo.ExG2.Object.IE_SetNoBBgColor_All( pBOARD, AttCr, SolBkCr2G ); 
				}
				else{
					SExo.ExG1.Object.IE_SetNoBBgColorNSel( pBOARD, FreeB0, AttCr, SolBkCr2G );
					if(ExG2.Object!=_na_)  SExo.ExG2.Object.IE_SetNoBBgColorNSel( pBOARD, FreeB0, AttCr, SolBkCr2G ); 			
				}

				SExo.ExG1.Object.IE_SetNoBBgColor_All( pBOARD, AttCr, SolBkCr2G ); 
				SExo.ExG2.Object.IE_SetNoBBgColor_All( pBOARD, AttCr, SolBkCr2G ); 

				if(SExo.Companions!=_na_) SExo.Companions.IE_SetNoBBgColorNSel( pBOARD, FreeB0, AttCr, SolBkCr2 );
						
				ExG1.Mirror81.IE_SetNoBBgColorNSel( pBOARD, FreeB0, AttCr, SolBkCr6 );
				ExG2.Mirror81.IE_SetNoBBgColorNSel( pBOARD, FreeB0, AttCr, SolBkCr6 );

			// ::: SLine
				SExo.ExG0.SLine_x.IE_SetNoBBgColorNSel( pBOARD, FreeB0, AttCr, SolBkCr4 );
				SExo.ExG1.SLine_x.IE_SetNoBBgColorNSel( pBOARD, FreeB0, AttCr, SolBkCr3 );
				SExo.ExG2.SLine_x.IE_SetNoBBgColorNSel( pBOARD, FreeB0, AttCr, SolBkCr3 );



			// ::: Report
				string stBase  = $"B:{SExo.Base81.TBScmp()}#{SExo.FreeB0.ToBitStringN(9)} Companion:{SExo.stCompanions}";
				string stObjL1 = $"T1:{ExG1.stObject} M1:{ExG1.stMirror81}";
				string stObjL2 = $"T2:{ExG2.stObject} M2:{ExG2.stMirror81}";
				
				string stBaseL  = $"   Base: {SExo.Base81.TBScmp()}#{SExo.FreeB0.ToBitStringN(9)}";
				string stObjL1L = $"Object1: {ExG1.stObject}  Mirror1:{ExG1.stMirror81}";
				string stObjL2L = $"Object2: {ExG2.stObject}  Mirror2:{ExG2.stMirror81}";
				string stWildcard = (SExo.WildCardB!=0)? $"Wildcard: #{SExo.WildCardB.ToBitStringN(9)}": "";

				Result     = $"��{ExocetNamePlus} {stBase} T1:{ExG1.stObject} T2:{ExG2.stObject}";
				
				string stL = $"{stBaseL}\n   {stObjL1L}\n   {stObjL2L}\n   Companions:{SExo.stCompanions}";
				ResultLong = $"Senior Exocet_NXG_{ExocetNamePlus}\n   {stL}";
				extResult = $"Senior Exocet_NXG_{ExocetNamePlus}\n  @dir:{SExo.dir}  @Stem:{SExo.rcStem.ToRCString()}\n\n   {stL}";
				
				if( SExo.ExocetName.Contains("JE1") || SExo.ExocetNamePlus.Contains("_Single") ){
					ResultLong += $"\n   {stWildcard}";
					extResult  += $"\n   {stWildcard}";
				}

				extResult += $"\n\n CoverLines (p:Parallel x:Cross){SExo.stCoverLines}";
				extResult += $"\n {SExo.stCrossCoverLineB}";
				extResult += "\n\n Firework\n" + SExo.Get_FireworkList();

				extResult += $"\n\n{new string('-',80)}\n Explanation of candidate digits exclusion\n";
					string stE = string.Join( "\n", extResultLst );
					int n1=stE.Length, n2;
					do{
						stE = stE.Replace("@\n@","@");
						if( n1==(n2=stE.Length) ) break;
						n1 = n2;
					}while(true);
				extResult += stE.Replace("+\n","+").Replace("@","\n").Replace("\n\n","\n").Replace("\n","\n  ");
					if(debugPrint)  WriteLine( "@@"+extResult );
			}
			catch( Exception e ){ WriteLine( $"{e.Message}\n{e.StackTrace}" ); }

			return;
					
		}
	}
}