using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Text;
using System.Linq;
using System.Collections;
using static System.Diagnostics.Debug;
using System.Xml.Serialization;

using GIDOO_space;
using GNPX_space.Properties;

namespace GNPX_space {
    //AHS(Almost Locked Set) 
    // AHS is a state where there are "n candidate digits" in "n+1 cells" belonging to the same house. 
    // https://gidoo-code.github.io/Sudoku_Solver_Generator_v5/page26.html

	// *==*==*==*==*==*==*==*==*==*
	//		version 5.1 
	// *==*==*==*==*==*==*==*==*==*

    public class UAnHS: USubset{

		public UAnHS             preAHS = null;
        public (UAnHS,int)       preAHS_no = (null,-9);
		public List<(UAnHS,int)> ConnectedAHS;
        public readonly new int  Size;          //FreeDigits Size 
        public readonly new int  Level;         //CellsSize-FreeDigits
		public List<int>         DigitList;
        public UAnHS(){ }

        public UAnHS( int ID, int FreeB, List<UCell> UCellLst ): base( ID, FreeB, UCellLst ){
		    this.Size      = UCellLst.Count;
            this.Level     = FreeB.BitCount()-Size;
			this.DigitList = FreeB.BitToNumList();
		}


        public bool IsPureAHS(){	// ...  Unconfirmed ...
            //Pure AHS : not include locked set of proper subset
            if( Size<=2 ) return true;

            for( int sz=2; sz<Size-1; sz++ ){		// Size: number of Free Digtis
                var cmb=new Combination(Size,sz);
                while(cmb.Successor()){
                    int fb=0;
                    for(int k=0; k<sz; k++ )  fb |= 1<<DigitList[cmb.Index[k]];
					int nc = UCellLst.Count( U => U.FreeB.DifSet(fb)==0 );
                    if( nc==sz ) return false;
                }
            }
            return true;
        }


		public override string ToString(){
            string st = $"\nUAnLS << ID:{ID} >>  [ Size:{Size} Level:{Level} ] ";
            st += $"  :{FreeB.ToBitString(9)}  FreeBwk:{FreeBwk.ToBitString(9)}\n";
            st += $" rcbFrame:{(rcbFrame).ToBitString27rcb()}";
			st += $" IsInsideBlock:{(IsInsideBlock? "@":"-")}";
            st += $"         bitExp:{bitExp.ToBitString81()}\n";
			st += $"connectedB81:{connectedB81.ToBitString81()}";

            for(int k=0; k<UCellLst.Count; k++){
                st += "\n------";
				UCell P = UCellLst[k];
                st += $" rc:{P.rc.ToRCString()}";
                st += $" FreeB:{P.FreeB.ToBitString(9)}";
				st += $" FreeBwk:{P.FreeBwk.ToBitString(9)}";			               
				st += $" // rcbFrame: {P.rcbFrame.ToBitString27rcb(digitB:false)}";
            }
            return st;
        }

        public new string ToStringA(){
            string st = $"<> UAnHS ID:{ID} Size:{Size} Level:{Level}  FreeB:{FreeB.ToBitString(9)} rc:{ToStringRCN()}";
            return  st;
        }

		public new string ToString_FreeBwk(){
			string st = $"UAnHS << ID:{ID} >>  [ Size:{Size} Level:{Level} ]";
			st += $"  FreeB:{FreeB.ToBitString(9)}  FreeBwk:{FreeBwk.ToBitString(9)}\n";
			st += $"         bitExp {bitExp.ToBitString81N()}\n";
			for(int k=0; k<UCellLst.Count; k++){
				st += "------";
				int rcW = UCellLst[k].rc;
				st += $" rc:{rcW.ToRCString()}";
				st += $" FreeBwk:{UCellLst[k].FreeBwk.ToBitString(9)}";
				st += $" rcb:b{(rcbBlk).ToBitString(9)}";
				st += $" c{rcbCol.ToBitString(9)}";
				st += $" r{rcbRow.ToBitString(9)}";
				//st += $" connectedB81:{connectedB81.ToBitString81N()}";
			  	st += "\n";
			}
            return st;
        }
	}

}
